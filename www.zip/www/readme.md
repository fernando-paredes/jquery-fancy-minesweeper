##Introduction

This is a experiment of making a Minesweeper game entirely based on the DOM, with almos no level of abstraction, so almost every interaction is made over the DOM itself and not applied to it.